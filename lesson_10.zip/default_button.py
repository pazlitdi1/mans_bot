from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from db import Database

menu_keyboard = ReplyKeyboardMarkup([
    [KeyboardButton("меню изображений 📸"), KeyboardButton("меню видео 🎞"), KeyboardButton("Mansur's | blog💻")],
    [KeyboardButton("музыкальное меню 🎵"), KeyboardButton("меню истории 🔍"), KeyboardButton("меню новостей 📰🗞")],
    [KeyboardButton("Instagram")],
    [KeyboardButton("Tik tok")],
        ],
    resize_keyboard=True)


# async def get_all_product():
menu_detail = ReplyKeyboardMarkup(resize_keyboard=True)
menu_detail.add(KeyboardButton("Продукт"), KeyboardButton("Продукт"))
menu_detail.add(KeyboardButton("Продукт"), KeyboardButton("Продукт"))
menu_detail.add(KeyboardButton("назад"))


product_button = ReplyKeyboardMarkup(resize_keyboard=True)
product_button.add(KeyboardButton("Back"))
